function build() {
  // build the package
}

module.exports = build
