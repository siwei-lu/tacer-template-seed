function test() {
  // test the package
}

module.exports = test
